# SNEducate-api
thesis API - Express.js
